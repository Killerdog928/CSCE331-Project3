/**
 * This file re-exports types from the Thumbnail module for easier import.
 */
export * from "./types";
